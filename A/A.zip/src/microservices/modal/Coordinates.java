package microservices.modal;

import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;

public class Coordinates implements Serializable {
	
	private ConcurrentHashMap<String, Double> mapOfCoor = new ConcurrentHashMap<>();
	
	public Coordinates () {}
	
	
	// get the coordinates with key as input
	 public Double getCoordinates(String key) {
        return mapOfCoor.get(key);
     }
	
	// add the coordinates to the map and then return the keys
    public void addCoordinates(String key , Double value) {
    	// put the coordinates to the list
        mapOfCoor.put(key, value);
        // 
    }
    
    public  Integer getCookie() {
    	return mapOfCoor.hashCode(); 
    }
    
    public boolean isEqualCookie(Integer cookie) {
    	if(cookie == mapOfCoor.hashCode()) {
    		return true;
    	}
    	return false;
    }

    
}
